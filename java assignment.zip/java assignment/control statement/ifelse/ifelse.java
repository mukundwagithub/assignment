public class ifelse
{
public static void main(String arg[])
{
int time = 20;
if (time < 18) 
{
  System.out.println("Good day.");
} 
else 
{
  System.out.println("Good evening.");
}
}
}